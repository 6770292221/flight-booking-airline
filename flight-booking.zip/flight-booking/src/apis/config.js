const config = {
    BASE_URL: 'http://localhost:3001/api/v1',
};

export default config;
